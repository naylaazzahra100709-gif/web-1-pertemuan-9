<?php
session_start();
require_once "koneksi.php";

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, "UTF-8");
}

$pesan = "";
$error = "";
$editData = null;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $aksi = $_POST["aksi"] ?? "";

    if ($aksi === "tambah" || $aksi === "ubah") {
        $nama = trim($_POST["nama_produk"] ?? "");
        $kategori = (int)($_POST["id_kategori"] ?? 0);
        $harga = (float)($_POST["harga"] ?? 0);
        $stok = (int)($_POST["stok"] ?? 0);

        if ($nama === "" || $kategori <= 0 || $harga < 0 || $stok < 0) {
            $error = "Lengkapi data dengan benar.";
        } else {
            if ($aksi === "tambah") {
                $stmt = $conn->prepare("INSERT INTO produk (id_kategori, nama_produk, harga, stok) VALUES (?, ?, ?, ?)");
                $stmt->bind_param("isdi", $kategori, $nama, $harga, $stok);
                if ($stmt->execute()) {
                    $_SESSION["pesan"] = "Produk berhasil ditambahkan.";
                    header("Location: index.php");
                    exit;
                } else {
                    $error = "Gagal menambahkan produk: " . $stmt->error;
                }
            } else {
                $id = (int)($_POST["id_produk"] ?? 0);
                $stmt = $conn->prepare("UPDATE produk SET id_kategori=?, nama_produk=?, harga=?, stok=? WHERE id_produk=?");
                $stmt->bind_param("isdii", $kategori, $nama, $harga, $stok, $id);
                if ($stmt->execute()) {
                    $_SESSION["pesan"] = "Produk berhasil diperbarui.";
                    header("Location: index.php");
                    exit;
                } else {
                    $error = "Gagal memperbarui produk: " . $stmt->error;
                }
            }
        }
    } elseif ($aksi === "hapus") {
        $id = (int)($_POST["id_produk"] ?? 0);
        $stmt = $conn->prepare("DELETE FROM produk WHERE id_produk=?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $_SESSION["pesan"] = "Produk berhasil dihapus.";
            header("Location: index.php");
            exit;
        } else {
            $error = "Gagal menghapus produk: " . $stmt->error;
        }
    }
}

if (isset($_SESSION["pesan"])) {
    $pesan = $_SESSION["pesan"];
    unset($_SESSION["pesan"]);
}

if (isset($_GET["edit"])) {
    $id = (int)$_GET["edit"];
    $stmt = $conn->prepare("SELECT * FROM produk WHERE id_produk=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $editData = $stmt->get_result()->fetch_assoc();
}

$kategoriResult = $conn->query("SELECT id_kategori, nama_kategori FROM kategori ORDER BY nama_kategori");
$cari = trim($_GET["cari"] ?? "");

$sql = "SELECT p.id_produk, p.nama_produk, k.nama_kategori, p.harga, p.stok
        FROM produk p
        INNER JOIN kategori k ON p.id_kategori = k.id_kategori";
if ($cari !== "") {
    $stmt = $conn->prepare($sql . " WHERE p.nama_produk LIKE ? OR k.nama_kategori LIKE ? ORDER BY p.id_produk DESC");
    $keyword = "%" . $cari . "%";
    $stmt->bind_param("ss", $keyword, $keyword);
    $stmt->execute();
    $produkResult = $stmt->get_result();
} else {
    $produkResult = $conn->query($sql . " ORDER BY p.id_produk DESC");
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Produk - Praktikum Web I</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<header class="topbar">
    <div class="container">
        <div class="brand">WEB I <span>•</span> DATA PRODUK</div>
        <div class="subtitle">Sistem Informasi Produk dan Kategori</div>
    </div>
</header>

<main class="container">
    <section class="intro">
        <div>
            <p class="eyebrow">DATABASE: web1_pertemuan09</p>
            <h1>Data Produk</h1>
            <p class="muted">Daftar produk yang terhubung dengan tabel kategori.</p>
        </div>
        <div class="pill">MySQL · PHP</div>
    </section>

    <?php if ($pesan !== ""): ?><div class="alert success"><?= e($pesan) ?></div><?php endif; ?>
    <?php if ($error !== ""): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>

    <section class="panel">
        <div class="panel-heading">
            <div>
                <h2><?= $editData ? "Ubah Produk" : "Tambah Produk" ?></h2>
                <p class="muted">Isi data sesuai kolom pada tabel produk.</p>
            </div>
            <?php if ($editData): ?><a class="btn btn-light" href="index.php">Batal edit</a><?php endif; ?>
        </div>
        <form method="post" class="form-grid">
            <input type="hidden" name="aksi" value="<?= $editData ? "ubah" : "tambah" ?>">
            <?php if ($editData): ?><input type="hidden" name="id_produk" value="<?= e($editData["id_produk"]) ?>"><?php endif; ?>
            <label>Nama Produk
                <input type="text" name="nama_produk" maxlength="120" required value="<?= e($editData["nama_produk"] ?? "") ?>" placeholder="Contoh: Buku Catatan">
            </label>
            <label>Kategori
                <select name="id_kategori" required>
                    <option value="">Pilih kategori</option>
                    <?php while ($kat = $kategoriResult->fetch_assoc()): ?>
                        <option value="<?= e($kat["id_kategori"]) ?>" <?= isset($editData["id_kategori"]) && (int)$editData["id_kategori"] === (int)$kat["id_kategori"] ? "selected" : "" ?>>
                            <?= e($kat["nama_kategori"]) ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </label>
            <label>Harga (Rp)
                <input type="number" name="harga" min="0" step="0.01" required value="<?= e($editData["harga"] ?? "") ?>" placeholder="12000">
            </label>
            <label>Stok
                <input type="number" name="stok" min="0" step="1" required value="<?= e($editData["stok"] ?? "") ?>" placeholder="20">
            </label>
            <div class="form-action">
                <button class="btn btn-primary" type="submit"><?= $editData ? "Simpan Edit" : "Simpan" ?></button>
            </div>
        </form>
    </section>

    <section class="panel">
        <div class="panel-heading table-heading">
            <div>
                <h2>Tabel Produk</h2>
                <p class="muted">Data diambil langsung dari database MySQL.</p>
            </div>
            <form method="get" class="search">
                <input type="search" name="cari" value="<?= e($cari) ?>" placeholder="Cari produk/kategori...">
                <button class="btn btn-dark" type="submit">Cari</button>
                <?php if ($cari !== ""): ?><a class="btn btn-light" href="index.php">Reset</a><?php endif; ?>
            </form>
        </div>
        <div class="table-wrap">
            <table>
                <thead>
                    <tr>
                        <th>ID</th><th>Nama Produk</th><th>Kategori</th>
                        <th>Harga</th><th>Stok</th><th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ($produkResult && $produkResult->num_rows > 0): ?>
                    <?php while ($row = $produkResult->fetch_assoc()): ?>
                    <tr>
                        <td class="number"><?= e($row["id_produk"]) ?></td>
                        <td class="product-name"><?= e($row["nama_produk"]) ?></td>
                        <td><span class="category"><?= e($row["nama_kategori"]) ?></span></td>
                        <td class="number">Rp <?= number_format((float)$row["harga"], 0, ",", ".") ?></td>
                        <td><span class="stock"><?= e($row["stok"]) ?></span></td>
                        <td class="actions">
                            <a class="btn btn-small btn-edit" href="index.php?edit=<?= e($row["id_produk"]) ?>">Edit</a>
                            <form method="post" onsubmit="return confirm('Yakin ingin menghapus produk ini?')">
                                <input type="hidden" name="aksi" value="hapus">
                                <input type="hidden" name="id_produk" value="<?= e($row["id_produk"]) ?>">
                                <button class="btn btn-small btn-delete" type="submit">Hapus</button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6" class="empty">Belum ada data produk yang cocok.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="table-foot">Relasi: <strong>produk.id_kategori</strong> → <strong>kategori.id_kategori</strong></div>
    </section>

    <footer>Praktikum Pemrograman Web I · Pertemuan 9 · Basis Data Relasional dan SQL CRUD</footer>
</main>
</body>
</html>
