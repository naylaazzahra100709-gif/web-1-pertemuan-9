WEB TABEL PRODUK - PERTEMUAN 9

Cara menjalankan:
1. Pastikan XAMPP sudah terpasang dan Apache serta MySQL aktif.
2. Pastikan database web1_pertemuan09 sudah ada di phpMyAdmin/MariaDB.
3. Salin folder web1_tabel_produk ke C:\xampp\htdocs\
4. Buka browser: http://localhost/web1_tabel_produk/
5. Jika MySQL root kamu memakai password, ubah variabel $password di koneksi.php.

Website membaca tabel kategori dan produk yang sudah ada. Fitur:
- Menampilkan data produk dan nama kategori (INNER JOIN)
- Menambah produk
- Mengubah produk
- Menghapus produk
- Mencari nama produk atau kategori

Jangan impor ulang praktikum.sql ke database yang sudah berisi data karena dapat menyebabkan data duplikat.
